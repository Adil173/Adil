<footer>
        <div class="center">
            <h2>Есть вопросы? Мы открыты для общения и поддержки 24/7</h2>
            <div class="pochta_center">
            <div class="pochta">
                <a href="#"><?php the_field('email'); ?></a>
                <a href="#"><?php the_field('email2'); ?></a>
            </div>
            </div>
            <div class="info">
                <div class="politika">
                <a href="">Условия использования</a>
                <p>Политика конфиденциальности</p>
                </div>
                <div class="soc_set">
                <a href="<?php the_field('instagram-link'); ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img//icons8-instagram-30.png" alt=""></a>
                <a href="<?php the_field('whatsapp-link'); ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img//icons8-whatsapp-30.png" alt=""></a>
                <a href="<?php the_field('facebook-link'); ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img//icons8-facebook-30.png" alt=""></a>
                <a href="<?php the_field('telegram-link'); ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img//icons8-логотип-telegram-30.png" alt=""></a>
                <a href="<?php the_field('youtube-link'); ?>"><img src="<?php bloginfo('template_url'); ?>/assets/img//icons8-youtube-play-30.png" alt=""></a>
                </div>
            </div>
            <p class="prava">© 2024 Nacometa. Все права защищены</p>
        </div>
    </footer>
</body>
</html>