<footer class="mt-20 bg-slate-600 pt-5 pb-5">
        <div class="text-center">
            <span>exam-2024</span>
        </div>
</footer>

    <?php wp_footer(); ?>
</body>
</html>